Summary   
=======================================

.. toctree::
  :maxdepth: 2

  introduction
  gui/index
  cli/index
  languages/index
  algorithms/index
  developer/index
  development/index


..
   Indices and tables
   ==================
   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`

