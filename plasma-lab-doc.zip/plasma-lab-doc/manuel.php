<?php
header('Location: http://plasma-lab.gforge.inria.fr/plasma_lab_doc/1.4.4/latex/PlasmaLab.pdf');
exit;
?>
