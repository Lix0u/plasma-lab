# Requirements

```sphinx``` (pip install sphinx)
```latex``` (to build a pdf)

```read the doc theme``` (pip install sphinx_rtd_theme)

# Compile

Type ```make``` to see all the options.
